
public interface TodoDaoInt {

  public String persist ();
  public String delete ();
  public String update ();

  public void findTodos ();

  public Long getId ();
  public void setId (Long id);

  public void destroy ();
}
